package com.bawp.myworkmanager;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class MyWorker extends Worker {

    public static final String TAG = "Work";
    public static final String DATA_KEY = "data_key";

    public MyWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Log.i(TAG, "Doing great work! ");
        // Pass data to Activity
        Data data = new Data.Builder()
                .putString(DATA_KEY, "Hello From doneWork!")
                .build();

        // Receive data from Activity
        String response = getInputData().getString(MyWorker.DATA_KEY);
        Log.i(TAG, "Received: " + response);



        return Result.success(data);
    }
}
