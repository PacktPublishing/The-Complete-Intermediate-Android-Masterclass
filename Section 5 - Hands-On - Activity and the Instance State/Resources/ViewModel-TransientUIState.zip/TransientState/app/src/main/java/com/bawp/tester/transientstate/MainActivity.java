package com.bawp.tester.transientstate;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.bawp.tester.transientstate.model.CounterViewModel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    Button button;

    private CounterViewModel mViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        //setup vieModel
        mViewModel = new ViewModelProvider(this).get(CounterViewModel.class);

        textView = findViewById(R.id.textView);
        button = findViewById(R.id.button);



        displayCounter(mViewModel.getCounter());

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 incrementCounter(v);


            }
        });
    }

    private void incrementCounter(View v) {
        mViewModel.setCounter(mViewModel.getCounter() + 1);
        displayCounter(mViewModel.getCounter());
    }

    private void displayCounter(int counter) {
        textView.setText(String.valueOf(counter));
    }
}
