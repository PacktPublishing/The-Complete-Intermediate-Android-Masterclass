package com.bawp.tester.android;

import android.graphics.Color;
import android.icu.text.RelativeDateTimeFormatter;
import android.os.Bundle;
import android.text.TextDirectionHeuristic;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

//    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Button myButton = new Button(this);
        myButton.setText(R.string.click);
        myButton.setBackgroundColor(Color.DKGRAY);

        RelativeLayout myLayout = new RelativeLayout(this);
        myLayout.setBackgroundColor(Color.WHITE);

        RelativeLayout.LayoutParams buttonParams = new RelativeLayout.LayoutParams(
                  RelativeLayout.LayoutParams.WRAP_CONTENT,
                 RelativeLayout.LayoutParams.WRAP_CONTENT
        );

        buttonParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
        buttonParams.addRule(RelativeLayout.CENTER_VERTICAL);

        myLayout.addView(myButton, buttonParams);




        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("Hello", "onClick: Hello" );
            }
        });

        setContentView(myLayout);





//
//        button = findViewById(R.id.go);
//        button.setOnClickListener(new View.OnClickListener() {
//
//            float rotVal = 0.9f;
//            @Override
//            public void onClick(View v) {
//
//                 findViewById(R.id.btn).animate().scaleX(rotVal += 1);
//            }
//        });

    }

}
