package com.bawp.tester.android;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button button;

    //Called at the start of the visible lifetime
    @Override
    protected void onStart() {
        super.onStart();

        // You can apply any necessary UI changes since the activity is visible
        // Start any processes that are required to ensure your UI is correctly
        //populated and updated.
        Log.d("OnCreate", "OnStart: Called! ");
        Toast toast = Toast.makeText(this, "OnStart Called!", Toast.LENGTH_SHORT);
        toast.show();
    }

    //Called at the end of the visible lifetime
    @Override
    protected void onStop() {
        super.onStop();
        //Suspend remaining UI updates, threads, or processing that aren't required when the Activity
        //isn't visible
        //Save all edits or state changes as your Activity may be killed at any time after onStop has
        //Completed

        Log.d("OnCreate", "OnStop: Called! ");
        Toast toast = Toast.makeText(this, "OnStop Called!", Toast.LENGTH_SHORT);
        toast.show();
    }

//    @Override
//    protected void onPostResume() {
//        super.onPostResume();
//        Toast toast = Toast.makeText(this, "OnResume Called!", Toast.LENGTH_SHORT);
//        toast.show();
//    }

    //Called before subsequent visible lifetimes for an Activity process.
    //Which means, before an activity returns to being visible previously been hidden.
    @Override
    protected void onRestart() {
        super.onRestart();

        //Load changes knowing that the Activity has already been visible within this process

        Log.d("OnCreate", "OnRestart: Called! ");
        Toast toast = Toast.makeText(this, "OnStop Called!", Toast.LENGTH_SHORT);
        toast.show();
    }

    // Called at the end of th active lifecycle
    @Override
    protected void onPause() {
        super.onPause();

        //Suspend UI updates, threads, or CPU intensive processes that don't need to
        //stick around.

        Log.d("OnCreate", "onPause: Called! ");
        Toast toast = Toast.makeText(this, "OnPause Called!", Toast.LENGTH_SHORT);
        toast.show();
    }

    // Called at the start of the active lifetime
    @Override
    protected void onResume() {
        super.onResume();

        //Resume any paused UI updates, threads, or processes required
        //by the Activity but suspended when it becomes inactive
        Log.d("OnCreate", "onResume: Called! ");

        Toast toast = Toast.makeText(this, "OnResume Called!", Toast.LENGTH_SHORT);
        toast.show();
    }

    // Sometimes called at the end of the full lifetime
    @Override
    protected void onDestroy() {
        super.onDestroy();

        //Full clean up of everything - resources, threads, close all database connections etc.

        Log.d("OnCreate", "OnDestroy: Called! ");
        Toast toast = Toast.makeText(this, "OnDestroy Called!", Toast.LENGTH_SHORT);
        toast.show();
    }

    // Called at the start of the full lifetime
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Initialize Activity and inflate the UI

        setContentView(R.layout.activity_main);


        Log.d("OnCreate", "onCreate: Called! ");

        Toast toast = Toast.makeText(this, "OnCreate Called!", Toast.LENGTH_SHORT);
        toast.show();

        button = findViewById(R.id.go);
        button.setOnClickListener(new View.OnClickListener() {

            float rotVal = 0.9f;

            @Override
            public void onClick(View v) {

                findViewById(R.id.btn).animate().scaleX(rotVal += 1);
            }
        });

    }

}
