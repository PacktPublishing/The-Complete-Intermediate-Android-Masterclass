package com.bawp.tester.fragmentstatically;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HelloFragment extends Fragment {


    public HelloFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_hello, container, false);


    }

    public void sayHello() {
         EditText editText = Objects.requireNonNull(getView()).findViewById(R.id.editText);
         TextView textView = getView().findViewById(R.id.textView);

         textView.setText(editText.getText().toString());
    }



}
