package com.bawp.tester.fragmentstatically;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    public static final String HELLO_FRAGMENT = "HELLO_TAG";

    HelloFragment helloFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fragmentManager = getSupportFragmentManager();

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        helloFragment = new HelloFragment();

        fragmentTransaction.add(R.id.main_frame, helloFragment, HELLO_FRAGMENT);

        fragmentTransaction.commit();


    }
}
