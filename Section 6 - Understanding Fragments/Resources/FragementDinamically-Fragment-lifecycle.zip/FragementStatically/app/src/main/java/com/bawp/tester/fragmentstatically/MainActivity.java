package com.bawp.tester.fragmentstatically;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    public static final String HELLO_FRAGMENT = "HELLO_TAG";

    HelloFragment helloFragment;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentManager fragmentManager = getSupportFragmentManager();

        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HelloFragment helloFragment = (HelloFragment) getSupportFragmentManager()
                        .findFragmentByTag(HELLO_FRAGMENT);

                if (helloFragment != null) {
                     helloFragment.sayHello();
                }


            }
        });


        if (savedInstanceState == null) {

            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            helloFragment = new HelloFragment();


            fragmentTransaction.add(R.id.main_frame, helloFragment, HELLO_FRAGMENT);

            fragmentTransaction.commit();

        } else {

            helloFragment = (HelloFragment) fragmentManager.findFragmentByTag(HELLO_FRAGMENT);

        }


    }
}
