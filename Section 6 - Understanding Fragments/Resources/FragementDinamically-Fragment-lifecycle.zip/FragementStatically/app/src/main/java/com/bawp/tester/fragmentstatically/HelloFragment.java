package com.bawp.tester.fragmentstatically;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HelloFragment extends Fragment {
    private EditText editText;
    private TextView textView;


    public HelloFragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        // The first to be fired!
        // Called when the Fragment instance is associated with an Activity
        //This does not mean the Activity is fully initialized!
        super.onAttach(context);
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      // Is called when Fragment should create its view object hierarchy, either dynamically or via XML layout inflation
        return inflater.inflate(R.layout.fragment_hello, container, false);


    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        // Called right after onCreateView is called.
        //Note: onViewCreated is only called if the view returned from onCreateView() is non-null
        // Any view setup should occur.  For example: view lookups and attaching view listeners.
        super.onViewCreated(view, savedInstanceState);

         editText = view.findViewById(R.id.editText);
         textView = view.findViewById(R.id.textView);
    }

    @Override
    public void onDestroyView() {
        // The fragment is about to be destroyed - cleanup!
        super.onDestroyView();
    }

    @Override
    public void onDetach() {
        // Is called when the fragment is no longer connected to the Activity
        // Get rid of references from onAttach() - null them out - to prevent memory leaks
        super.onDetach();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        //This method is called after the parent Activity's onCreate() method has completed
        super.onActivityCreated(savedInstanceState);
    }

    void sayHello() {

         textView.setText(editText.getText().toString());
    }



}
