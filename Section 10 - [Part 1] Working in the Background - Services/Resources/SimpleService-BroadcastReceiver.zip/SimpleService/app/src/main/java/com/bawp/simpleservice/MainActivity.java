package com.bawp.simpleservice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                int sum = bundle.getInt(MyService.SUM);
                int resultCode = bundle.getInt(MyService.RESULT);

                if (resultCode == RESULT_OK) {
                     textView.setText(String.format("Process complete with sum %s",
                             String.valueOf(sum)));

                }else {
                     textView.setText(R.string.failed);
                }
            }

        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(receiver, new IntentFilter(MyService.NOTIFICATION));
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         textView = findViewById(R.id.textView);
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start service
                Intent intent = new Intent(getApplicationContext(), MyService.class);
                intent.putExtra(MyService.KEY_NUM, 90);
                startService(intent);

            }
        });
    }
}
