package com.bawp.myjobscheduler.services;

import android.app.Service;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class MyService extends JobService {

    public static final String TAG = "JOB";
    public static final String MACTION = "com.bawp.myapp";
    public static final String VAL = "val";
    private boolean jobCancelled = false;

    @Override
    public boolean onStartJob(JobParameters params) {
        Log.i(TAG, "onStartJob: "+ params.getJobId());
        //jobFinished(params, false);
        doBackgroundWork(params);
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        Log.i(TAG, "onStopJob: " + params.getJobId());
        jobCancelled = true;
        return true;
    }
    private void doBackgroundWork(final JobParameters parameters) {

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                Intent jobIntent = new Intent(MACTION);

                for (int i = 0; i < 10; i++) {
                    Log.i(TAG, "run: " + i);
                    if (jobCancelled){
                        return;
                    }
                    // send to UI using BroadcastReceiver
                    jobIntent.putExtra(VAL, i);
                    sendBroadcast(jobIntent);


                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
                Log.i(TAG, "run: Job done! ");
                // Tell the system that we are finished!
                jobFinished(parameters, false);


            }
        };
        Thread thread = new Thread(runnable);
        thread.start();
    }
}
