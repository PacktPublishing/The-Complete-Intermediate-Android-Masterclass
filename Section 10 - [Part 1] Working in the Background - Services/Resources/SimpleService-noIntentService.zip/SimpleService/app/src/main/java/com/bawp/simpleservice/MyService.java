package com.bawp.simpleservice;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class MyService extends Service {
    public static final String KEY_NUM = "key_num";
    public static final String TAG = "Running Service";
    public MyService() {
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int a = intent.getIntExtra(KEY_NUM, 1);
        Log.i(TAG, "onStartCommand: " + sum(a));


        return Service.START_NOT_STICKY;

    }

    private int sum(int a) {
        return (a+a);
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
