package com.bawp.customcard;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CreateCardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_card);
    }
}
