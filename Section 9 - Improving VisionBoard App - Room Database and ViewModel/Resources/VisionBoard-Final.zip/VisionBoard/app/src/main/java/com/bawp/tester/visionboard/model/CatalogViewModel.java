package com.bawp.tester.visionboard.model;

import android.app.Application;

import com.bawp.tester.visionboard.data.ApplicationDatabase;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

public class CatalogViewModel extends AndroidViewModel {
    private LiveData<List<Board>> boards;


    public CatalogViewModel(@NonNull Application application) {
        super(application);
        ApplicationDatabase database =
                ApplicationDatabase.getInstance(this.getApplication());
        boards = database.boardDao().loadAllBoards();
    }
    public LiveData<List<Board>> getBoards() {return boards;}

}
