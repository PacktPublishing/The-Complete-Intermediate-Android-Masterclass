package com.bawp.tester.visionboard.data;

import android.content.Context;

import com.bawp.tester.visionboard.model.Board;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Board.class}, version = 1, exportSchema = false)
public abstract class ApplicationDatabase extends RoomDatabase {
    private static final String DATABASE_NAME = "board_db";
    private static ApplicationDatabase INSTANCE;

    public static ApplicationDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(
                    context.getApplicationContext(),
                    ApplicationDatabase.class,
                    ApplicationDatabase.DATABASE_NAME
            ).build();
        }
        return INSTANCE;

    }
    public abstract BoardDao boardDao();
}
