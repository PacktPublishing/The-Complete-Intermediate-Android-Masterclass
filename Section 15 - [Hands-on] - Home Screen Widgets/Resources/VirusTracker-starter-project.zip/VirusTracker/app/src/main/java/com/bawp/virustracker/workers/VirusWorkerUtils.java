package com.bawp.virustracker.workers;

public class VirusWorkerUtils {
}
