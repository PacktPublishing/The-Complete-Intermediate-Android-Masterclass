package com.bawp.virustracker.workers;

import android.content.Context;
import android.content.res.Resources;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import static com.bawp.virustracker.Constants.CLEANING;

public class CleanupWorker extends Worker {
    public CleanupWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Data data = new Data.Builder()
                .putString(CLEANING, "Cleaning...")
                .build();

        return Result.success(data);
    }
}
